"""User-operated school login, with secrets staying outside the agent conversation."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from collections.abc import Callable
from pathlib import Path
from urllib.parse import parse_qsl, urlencode, urlparse

from .features.jw.parser import jw_authenticated
from .interaction import require_interaction
from .network import PASSWORD_KEYS, CampusHTTP, scoped_state
from .parsing import is_login
from .runtime import AppError, key_lock
from .sources import JW_HOME, JW_LOGIN_URL, MYSTU_API, MYSTU_BASE, SOURCES, YUKETANG_BASE
from .store import Store
from .vault import Vault


def sync_playwright():
    """Browser support is loaded only by an explicit compatibility login."""
    try:
        from playwright.sync_api import sync_playwright as start
    except ImportError:
        raise AppError("browser_unavailable", "浏览器兼容登录未安装；HTTP 登录不需要此依赖。") from None
    return start()


def login_service(service: str) -> str:
    if service == "webvpn":
        return "oa"
    if service not in {"jw", "mystu", "yuketang", "oa"}:
        raise AppError("unknown_service", "请选择教务、MySTU、雨课堂或 WebVPN。")
    return service


def proof(source: str, state: dict, *, legacy_jw: bool = False) -> bool:
    """A cookie's existence is not proof of a working authenticated school endpoint."""
    try:
        with CampusHTTP(source, state, allow_legacy_http=legacy_jw) as http:
            if source == "jw":
                return jw_authenticated(http.text(JW_HOME))
            elif source == "mystu":
                data = http.json(MYSTU_API + "/user/validate?ver=1.1")
                from .auth_http.cas import validate_identity
                validate_identity(data)
            elif source == "yuketang":
                data = http.json(YUKETANG_BASE + "/v2/api/web/courses/list?identity=2")
                from .auth_http.yuketang import validate_student_courses
                return validate_student_courses(data)["authenticated"]
            else:
                # WebVPN is only stored provisionally; OA refresh must validate access over HTTPS.
                return bool(state.get("cookies"))
        return True
    except AppError as exc:
        # Only authentication evidence means the user should continue signing in.
        # Surface permission, rate-limit, network and schema failures instead of
        # silently polling them until a misleading "login timeout".
        if exc.code not in {"needs_login", "login_expired"}:
            raise
        return False


def browser_http_allowed(url: str, post_data: str | None, *, legacy_jw: bool) -> bool:
    """The JW exception never authorizes HTTP password submissions or other hosts."""
    parsed = urlparse(url)
    if not legacy_jw or parsed.scheme != "http" or parsed.hostname != "jw.stu.edu.cn" or parsed.port not in (None, 80):
        return False
    pairs = parse_qsl(parsed.query) + parse_qsl(post_data or "")
    if any(k.lower() in PASSWORD_KEYS for k, _ in pairs):
        return False
    try:
        payload = json.loads(post_data or "null")
    except ValueError:
        payload = None
    return not (isinstance(payload, dict) and any(k.lower() in PASSWORD_KEYS for k in payload))


def prepare_browser(playwright, on_phase: Callable[[str], None] | None = None):
    if not Path(playwright.chromium.executable_path).is_file():
        if on_phase:
            on_phase("preparing_browser")
        try:
            installed = subprocess.run([sys.executable, "-m", "playwright", "install", "chromium"],
                                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                       timeout=300, check=False,
                                       creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
        except (OSError, subprocess.TimeoutExpired):
            raise AppError("browser_install_failed", "登录浏览器准备失败，请检查下载网络后重新登录。") from None
        if installed.returncode:
            raise AppError("browser_install_failed", "登录浏览器下载失败；可执行 stu-mcp browser install 检查。")


def interactive_login(vault: Vault, service: str, *, timeout: int = 300,
                      on_phase: Callable[[str], None] | None = None,
                      expected_revision: bytes | None = None) -> dict:
    source = login_service(service)
    require_interaction(source)
    spec = SOURCES[source]
    if expected_revision is None:
        with key_lock(vault.runtime.home, spec.session):
            expected_revision = vault.login_revision(spec.session)
    legacy_jw = source == "jw" and vault.runtime.preferences()["jw_http_compat"]
    login_url = ("https://sso.stu.edu.cn/login?" + urlencode({"service": JW_LOGIN_URL.replace("https:", "http:", 1)})
                 if legacy_jw else spec.login_url)
    vault._key(create=True)  # Verify secure storage before asking the user to log in.
    webvpn_config = webvpn_snapshot = None
    if source == "oa":
        from .webvpn import WebVPNConfig
        webvpn_config = WebVPNConfig(vault)
        webvpn_snapshot = webvpn_config.snapshot()
    def check_login():
        if vault.login_revision(spec.session) != expected_revision:
            raise AppError("session_changed", "登录期间已退出或切换账号，此次会话未保存；请重新登录。", source)
        if webvpn_config:
            webvpn_config.check(webvpn_snapshot)
    insecure_navigation = [False]
    try:
        try:
            from playwright.sync_api import Error as BrowserError
        except ImportError:
            raise AppError("browser_unavailable", "浏览器兼容登录未安装；HTTP 登录不需要此依赖。", source) from None
        with sync_playwright() as p:
            prepare_browser(p, on_phase)
            if on_phase:
                on_phase("waiting_for_login")
            browser = p.chromium.launch(headless=False)
            context = browser.new_context(ignore_https_errors=False)
            # Passwords stay on HTTPS; an explicit local option permits only the school's legacy JW service.
            def guard(route):
                parsed = urlparse(route.request.url)
                if parsed.scheme == "http" and not browser_http_allowed(route.request.url, route.request.post_data,
                                                                       legacy_jw=legacy_jw):
                    if route.request.is_navigation_request():
                        insecure_navigation[0] = True
                    route.abort()
                else:
                    route.continue_()
            context.route("**/*", guard)
            page = context.new_page()
            page.goto(login_url, wait_until="domcontentloaded", timeout=45000)
            deadline = time.monotonic() + timeout
            last_probe = 0.0
            while time.monotonic() < deadline:
                if insecure_navigation[0]:
                    raise AppError("insecure_transport", "HTTP 回调被拦截。浏览器兼容登录可通过 "
                                   "stu-mcp transport --jw-http on 启用教务官方回调。", source)
                if not browser.is_connected() or page.is_closed():
                    raise AppError("login_cancelled", "登录窗口已关闭；尚未保存会话。", source)
                page.wait_for_timeout(1000)
                current = urlparse(page.url)
                if current.hostname not in spec.hosts or current.hostname == "sso.stu.edu.cn":
                    continue
                html = page.content()
                if current.scheme == "http" and is_login(html):
                    raise AppError("insecure_password_form", "教务返回了 HTTP 登录表单，请关闭窗口并改用学校 HTTPS 统一认证。", source)
                if is_login(html) or page.locator('input[autocomplete="one-time-code"]').count():
                    continue
                if time.monotonic() - last_probe < 4:
                    continue
                last_probe = time.monotonic()
                state = scoped_state(context.storage_state(), source)
                if not state["cookies"] or not proof(source, state, legacy_jw=legacy_jw):
                    continue
                if source == "oa" and ("portal" not in current.path or "service" not in current.fragment):
                    continue
                if source == "mystu":
                    # Bootstrap the Moodle session in the same user-operated browser.
                    page.goto(MYSTU_BASE + "/courses/elc/", wait_until="domcontentloaded", timeout=45000)
                    if is_login(page.content()) or urlparse(page.url).hostname == "sso.stu.edu.cn":
                        continue
                    state = scoped_state(context.storage_state(), source)
                def forget_previous():
                    Store(vault.runtime, vault).forget(source)
                    if webvpn_config:
                        webvpn_config.remove_locked()
                vault.save(spec.session, state, on_relogin=forget_previous,
                           guard=check_login)
                browser.close()
                return {"ok": True, "service": spec.session, "status": "session_saved",
                        "verified_live": source != "oa", "next_step": "现在可刷新此来源。"}
            browser.close()
    except AppError:
        raise
    except BrowserError:
        if insecure_navigation[0]:
            raise AppError("insecure_transport", "HTTP 回调被拦截；浏览器兼容登录可通过 "
                           "stu-mcp transport --jw-http on 启用教务官方回调。", source) from None
        raise AppError("browser_unavailable", "登录浏览器无法启动或学校页面无法访问。请运行 stu-mcp browser install 并检查网络。",
                       source) from None
    raise AppError("login_timeout", "登录等待超时；未保存未验证的登录会话。", source)
