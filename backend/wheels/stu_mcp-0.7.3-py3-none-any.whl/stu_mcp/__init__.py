"""STU MCP: on-demand campus tools, independent of any agent runtime."""

__version__ = "0.7.3"
